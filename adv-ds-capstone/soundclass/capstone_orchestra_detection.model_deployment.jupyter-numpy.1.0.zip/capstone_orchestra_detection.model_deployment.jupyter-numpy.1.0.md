```python

import matplotlib.pyplot as plt 
import numpy as np
from scipy.io import wavfile
from numpy.fft import fft, ifft
import scipy.signal as sig

```

# model_deployment

external dependencies:
* ./audiolibrary.json
* ./footprints.json
* ./predictionclasses.csv

# loading the definition of the samples and footprints (engineered features)

11 samples taken from two separate online archives - one for training purposes and one for testing
* https://theremin.music.uiowa.edu/MIS-Pitches-2012/ - for training (6 samples)
* https://freesound.org - for testing (5 samples)


```python
import json
with open('audiolibrary.json') as audiolibrary_file:
    library = json.load(audiolibrary_file)
    
print('library loaded with',len(library),'items')
```

    library loaded with 18 items
    


```python
def check_uniqueness_of_library_field(library,field):
    labels = [ dd[field] for dd in library]
    print(len(labels),field)
    return len(labels) == len(set(labels))
```


```python
assert check_uniqueness_of_library_field(library,'label')
assert check_uniqueness_of_library_field(library,'wav')
```

    18 label
    18 wav
    


```python
import json
with open('footprints.json') as footprints_file:
    footprints = json.load(footprints_file)
    
print('footprints loaded with',len(footprints),'items')
```

    footprints loaded with 18 items
    


```python
import pandas as pd
```

## load istm-dummy mapping for prediction models (M)


```python
dfm= pd.read_csv('predictionclasses.csv') # ,index_col='class')
assert dfm.columns.tolist() == 'istm,class,classn'.split(',')
dfm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>istm</th>
      <th>class</th>
      <th>classn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bassoon</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Viola</td>
      <td>1</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Cello</td>
      <td>2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>FrHorn</td>
      <td>3</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Flute</td>
      <td>4</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Clarinet</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
  </tbody>
</table>
</div>



## loading the footprints (each with custom pairs of freq/magnitude) in a dataframe


```python

dfu = None
for fp in footprints:
    NR = len(fp['pkf'])
    #print(fp['label'],fp['train'],'NR',NR)
    #print(NR,fp['pkf'],fp['pkm'])
    df = pd.DataFrame({
        'label':[fp['label']]*NR,
        'train':[fp['train']]*NR,
        'istm':[fp['istm']]*NR,
        'note':[fp['note']]*NR,
        'freq':fp['pkf'],
        'magn':fp['pkm']
    })
    if dfu is None:
        dfu = df
    else:
        dfu = pd.concat([dfu,df],ignore_index=True)
```


```python
dfu.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>train</th>
      <th>istm</th>
      <th>note</th>
      <th>freq</th>
      <th>magn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>440.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>881.981982</td>
      <td>10.699971</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>1321.981982</td>
      <td>0.798439</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>1763.963964</td>
      <td>1.161748</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>2203.963964</td>
      <td>0.419192</td>
    </tr>
  </tbody>
</table>
</div>




```python
dfu = dfu.join(dfm.set_index('istm'),on='istm')
dfu.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>train</th>
      <th>istm</th>
      <th>note</th>
      <th>freq</th>
      <th>magn</th>
      <th>class</th>
      <th>classn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>440.000000</td>
      <td>1.000000</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>881.981982</td>
      <td>10.699971</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>1321.981982</td>
      <td>0.798439</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>1763.963964</td>
      <td>1.161748</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>2203.963964</td>
      <td>0.419192</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>



### stats on peaks for each footprint
SELECT label, max(freq), count(*)
FROM dfu
GROUP BY label

```python
dfu.groupby('label')['freq'].agg(['min', 'max', 'count'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>min</th>
      <th>max</th>
      <th>count</th>
    </tr>
    <tr>
      <th>label</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Bassoon1a</th>
      <td>440.0</td>
      <td>8377.837838</td>
      <td>17</td>
    </tr>
    <tr>
      <th>Bassoon2a</th>
      <td>440.0</td>
      <td>2200.000000</td>
      <td>5</td>
    </tr>
    <tr>
      <th>Bassoon3a_x</th>
      <td>440.0</td>
      <td>4842.211055</td>
      <td>11</td>
    </tr>
    <tr>
      <th>Cello1a</th>
      <td>440.0</td>
      <td>7942.000000</td>
      <td>17</td>
    </tr>
    <tr>
      <th>Cello2a</th>
      <td>440.0</td>
      <td>9222.983425</td>
      <td>18</td>
    </tr>
    <tr>
      <th>Cello3a_x</th>
      <td>440.0</td>
      <td>9346.944444</td>
      <td>19</td>
    </tr>
    <tr>
      <th>Clarinet1a</th>
      <td>440.0</td>
      <td>5284.000000</td>
      <td>11</td>
    </tr>
    <tr>
      <th>Clarinet2a</th>
      <td>440.0</td>
      <td>2190.638298</td>
      <td>4</td>
    </tr>
    <tr>
      <th>Clarinet3a_x</th>
      <td>440.0</td>
      <td>8345.729730</td>
      <td>18</td>
    </tr>
    <tr>
      <th>Flute1a</th>
      <td>440.0</td>
      <td>4412.941176</td>
      <td>9</td>
    </tr>
    <tr>
      <th>Flute2a</th>
      <td>440.0</td>
      <td>3486.412214</td>
      <td>8</td>
    </tr>
    <tr>
      <th>Flute3a_x</th>
      <td>440.0</td>
      <td>4834.666667</td>
      <td>11</td>
    </tr>
    <tr>
      <th>FrHorn1a</th>
      <td>440.0</td>
      <td>6589.049774</td>
      <td>12</td>
    </tr>
    <tr>
      <th>FrHorn2a</th>
      <td>440.0</td>
      <td>8339.908676</td>
      <td>19</td>
    </tr>
    <tr>
      <th>FrHorn3a_x</th>
      <td>440.0</td>
      <td>4388.288973</td>
      <td>10</td>
    </tr>
    <tr>
      <th>Viola1a</th>
      <td>440.0</td>
      <td>7037.981651</td>
      <td>15</td>
    </tr>
    <tr>
      <th>Viola2a</th>
      <td>440.0</td>
      <td>7942.335025</td>
      <td>13</td>
    </tr>
    <tr>
      <th>Viola3a_x</th>
      <td>440.0</td>
      <td>1545.641026</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
samples = dfu[['label','train','istm','note']].drop_duplicates()
samples
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>train</th>
      <th>istm</th>
      <th>note</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Bassoon2a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A4</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Bassoon3a_x</td>
      <td>0</td>
      <td>Bassoon</td>
      <td>G3</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Viola1a</td>
      <td>1</td>
      <td>Viola</td>
      <td>A3</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Viola2a</td>
      <td>1</td>
      <td>Viola</td>
      <td>G3</td>
    </tr>
    <tr>
      <th>61</th>
      <td>Viola3a_x</td>
      <td>0</td>
      <td>Viola</td>
      <td>G4</td>
    </tr>
    <tr>
      <th>64</th>
      <td>Cello1a</td>
      <td>1</td>
      <td>Cello</td>
      <td>A2</td>
    </tr>
    <tr>
      <th>81</th>
      <td>Cello2a</td>
      <td>1</td>
      <td>Cello</td>
      <td>F3</td>
    </tr>
    <tr>
      <th>99</th>
      <td>Cello3a_x</td>
      <td>0</td>
      <td>Cello</td>
      <td>D3</td>
    </tr>
    <tr>
      <th>118</th>
      <td>FrHorn1a</td>
      <td>1</td>
      <td>FrHorn</td>
      <td>A4</td>
    </tr>
    <tr>
      <th>130</th>
      <td>FrHorn2a</td>
      <td>1</td>
      <td>FrHorn</td>
      <td>A2</td>
    </tr>
    <tr>
      <th>149</th>
      <td>FrHorn3a_x</td>
      <td>0</td>
      <td>FrHorn</td>
      <td>C4</td>
    </tr>
    <tr>
      <th>159</th>
      <td>Flute1a</td>
      <td>1</td>
      <td>Flute</td>
      <td>A4</td>
    </tr>
    <tr>
      <th>168</th>
      <td>Flute2a</td>
      <td>1</td>
      <td>Flute</td>
      <td>G4</td>
    </tr>
    <tr>
      <th>176</th>
      <td>Flute3a_x</td>
      <td>0</td>
      <td>Flute</td>
      <td>E4</td>
    </tr>
    <tr>
      <th>187</th>
      <td>Clarinet1a</td>
      <td>1</td>
      <td>Clarinet</td>
      <td>A4</td>
    </tr>
    <tr>
      <th>198</th>
      <td>Clarinet2a</td>
      <td>1</td>
      <td>Clarinet</td>
      <td>F5</td>
    </tr>
    <tr>
      <th>202</th>
      <td>Clarinet3a_x</td>
      <td>0</td>
      <td>Clarinet</td>
      <td>F#3</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.crosstab(index=samples.istm,columns=samples.train,values=samples.label,aggfunc='count')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>train</th>
      <th>0</th>
      <th>1</th>
    </tr>
    <tr>
      <th>istm</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Bassoon</th>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>Cello</th>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>Clarinet</th>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>Flute</th>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>FrHorn</th>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>Viola</th>
      <td>1</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
# round the frequencies
dfu['freq'] = round(dfu['freq'],2)
```

# approach 1 - merge all
### CORR_ON_LININTERP_MERGED_PEAKFREQS

* take the union of all the freqs of the datapoints of all the samples
* interpolate
* now you have a PANEL DATA
* compute the correlations of the interpolated-paneled footprints
* reploy to classification requests using the correlation matrix


```python
# using dfu
```


```python
ctab = pd.crosstab(index = [dfu.freq], columns = dfu.label, values=dfu.magn, aggfunc='max')#.unstack()
# max function: thanks to the previous assertion, we are sure that max *is* the ONLY value itself.
ctab.head()
# https://stackoverflow.com/questions/46829769/pandas-dataframe-flatten-crosstab-with-multilevel-index ...?
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>label</th>
      <th>Bassoon1a</th>
      <th>Bassoon2a</th>
      <th>Bassoon3a_x</th>
      <th>Cello1a</th>
      <th>Cello2a</th>
      <th>Cello3a_x</th>
      <th>Clarinet1a</th>
      <th>Clarinet2a</th>
      <th>Clarinet3a_x</th>
      <th>Flute1a</th>
      <th>Flute2a</th>
      <th>Flute3a_x</th>
      <th>FrHorn1a</th>
      <th>FrHorn2a</th>
      <th>FrHorn3a_x</th>
      <th>Viola1a</th>
      <th>Viola2a</th>
      <th>Viola3a_x</th>
    </tr>
    <tr>
      <th>freq</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>440.00</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>873.28</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.953322</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>876.88</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.268549</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>877.57</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.216723</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>878.67</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7.179289</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
ctab_intrp = ctab.interpolate(method='slinear') # linear, quadratic, cubic...
#https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.interpolate.html#pandas.DataFrame.interpolate
ctab_intrp.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>label</th>
      <th>Bassoon1a</th>
      <th>Bassoon2a</th>
      <th>Bassoon3a_x</th>
      <th>Cello1a</th>
      <th>Cello2a</th>
      <th>Cello3a_x</th>
      <th>Clarinet1a</th>
      <th>Clarinet2a</th>
      <th>Clarinet3a_x</th>
      <th>Flute1a</th>
      <th>Flute2a</th>
      <th>Flute3a_x</th>
      <th>FrHorn1a</th>
      <th>FrHorn2a</th>
      <th>FrHorn3a_x</th>
      <th>Viola1a</th>
      <th>Viola2a</th>
      <th>Viola3a_x</th>
    </tr>
    <tr>
      <th>freq</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>440.00</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>873.28</th>
      <td>10.509035</td>
      <td>0.955160</td>
      <td>1.282774</td>
      <td>0.719496</td>
      <td>0.224402</td>
      <td>3.209029</td>
      <td>0.270081</td>
      <td>0.274576</td>
      <td>0.054055</td>
      <td>1.540813</td>
      <td>0.953322</td>
      <td>7.103363</td>
      <td>0.452625</td>
      <td>1.296627</td>
      <td>1.728135</td>
      <td>0.756879</td>
      <td>6.715393</td>
      <td>0.608748</td>
    </tr>
    <tr>
      <th>876.88</th>
      <td>10.588043</td>
      <td>0.954788</td>
      <td>1.285124</td>
      <td>0.717165</td>
      <td>0.217958</td>
      <td>3.227383</td>
      <td>0.264017</td>
      <td>0.268549</td>
      <td>0.046196</td>
      <td>1.545307</td>
      <td>0.947910</td>
      <td>7.154074</td>
      <td>0.448077</td>
      <td>1.299091</td>
      <td>1.734185</td>
      <td>0.754859</td>
      <td>6.762881</td>
      <td>0.605498</td>
    </tr>
    <tr>
      <th>877.57</th>
      <td>10.603186</td>
      <td>0.954716</td>
      <td>1.285574</td>
      <td>0.716718</td>
      <td>0.216723</td>
      <td>3.230901</td>
      <td>0.262854</td>
      <td>0.268687</td>
      <td>0.044689</td>
      <td>1.546168</td>
      <td>0.946873</td>
      <td>7.163793</td>
      <td>0.447206</td>
      <td>1.299564</td>
      <td>1.735344</td>
      <td>0.754472</td>
      <td>6.771983</td>
      <td>0.604875</td>
    </tr>
    <tr>
      <th>878.67</th>
      <td>10.627328</td>
      <td>0.954602</td>
      <td>1.286292</td>
      <td>0.716006</td>
      <td>0.216475</td>
      <td>3.236509</td>
      <td>0.261001</td>
      <td>0.268908</td>
      <td>0.042288</td>
      <td>1.547541</td>
      <td>0.945219</td>
      <td>7.179289</td>
      <td>0.445816</td>
      <td>1.300317</td>
      <td>1.737193</td>
      <td>0.753855</td>
      <td>6.786493</td>
      <td>0.603881</td>
    </tr>
  </tbody>
</table>
</div>




```python
del ctab
```


```python
ax = ctab_intrp.plot(figsize=(15, 8))
```


    
![png](output_26_0.png)
    



```python
ax = ctab_intrp.plot.bar(figsize=(20, 8))
```


    
![png](output_27_0.png)
    



```python
import seaborn as sns
corr = ctab_intrp.corr()
ax = sns.heatmap(corr,cmap="coolwarm")
```


    
![png](output_28_0.png)
    



```python
def get_the_samples_to_test(dfu):
    dfut = dfu[['label','train']].drop_duplicates().set_index('label')
    totest = dfut.query('train==0').index.tolist()
    return totest
```


```python
def get_the_best_corrbased_match1(corr,dfu,testlabel1):
    dfut = dfu[['label','train','istm']].drop_duplicates().set_index('label')
    corr_w_trainflag = corr.join(dfut)
    candidates = corr_w_trainflag.query("train==1")[testlabel1]
    return { 'q': testlabel1, 'a': candidates.idxmax(), 'corr': candidates.max() }
```


```python
def get_the_best_corrbased_matches(corr,dfu):
    dfa = pd.DataFrame({'q':[],'a':[],'corr':[]})
    totest = get_the_samples_to_test(dfu)
    for testlabel in totest:
        dfa.loc[len(dfa)] = get_the_best_corrbased_match1(corr,dfu,testlabel)
    return dfa
```


```python
dfco = get_the_best_corrbased_matches(corr,dfu)
dfco
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>q</th>
      <th>a</th>
      <th>corr</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bassoon3a_x</td>
      <td>Flute1a</td>
      <td>0.909310</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Viola3a_x</td>
      <td>Cello1a</td>
      <td>0.983810</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Cello3a_x</td>
      <td>Viola1a</td>
      <td>0.919549</td>
    </tr>
    <tr>
      <th>3</th>
      <td>FrHorn3a_x</td>
      <td>Flute1a</td>
      <td>0.962820</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Flute3a_x</td>
      <td>Flute1a</td>
      <td>0.930254</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Clarinet3a_x</td>
      <td>Clarinet2a</td>
      <td>0.924670</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2export = dfco.join(
                dfu[['label','class']].drop_duplicates().set_index('label'), # label, class
                on='a')[['q','class']].rename(columns={
                    'q':'test_sample','class':'predicted_class'
                })
df2export
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>test_sample</th>
      <th>predicted_class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bassoon3a_x</td>
      <td>4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Viola3a_x</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Cello3a_x</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>FrHorn3a_x</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Flute3a_x</td>
      <td>4</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Clarinet3a_x</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2export.reset_index(drop=True).to_csv('modelprediction.CORR_ON_LININTERP_MERGED_PEAKFREQS.1.csv')
```


```python
del corr
del ctab_intrp
```

# approach 2

### MAE_ON_MEAN_ROUNDED_PEAKFREQS


```python
# using: dfu
```


```python
# create rounded frequencies
dfu['rfreq'] = round(440. * round(dfu['freq'] / 440.),1)
```


```python
ctab_rnd = pd.crosstab(index = dfu.rfreq, columns = dfu.label, values=dfu.magn, aggfunc='mean')
ctab_rnd.head()
# https://stackoverflow.com/questions/46829769/pandas-dataframe-flatten-crosstab-with-multilevel-index ...?
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>label</th>
      <th>Bassoon1a</th>
      <th>Bassoon2a</th>
      <th>Bassoon3a_x</th>
      <th>Cello1a</th>
      <th>Cello2a</th>
      <th>Cello3a_x</th>
      <th>Clarinet1a</th>
      <th>Clarinet2a</th>
      <th>Clarinet3a_x</th>
      <th>Flute1a</th>
      <th>Flute2a</th>
      <th>Flute3a_x</th>
      <th>FrHorn1a</th>
      <th>FrHorn2a</th>
      <th>FrHorn3a_x</th>
      <th>Viola1a</th>
      <th>Viola2a</th>
      <th>Viola3a_x</th>
    </tr>
    <tr>
      <th>rfreq</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>440.0</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>880.0</th>
      <td>10.699971</td>
      <td>0.954465</td>
      <td>1.287160</td>
      <td>0.715145</td>
      <td>0.216723</td>
      <td>3.258891</td>
      <td>0.257076</td>
      <td>0.268549</td>
      <td>0.039384</td>
      <td>1.554169</td>
      <td>0.953322</td>
      <td>7.179289</td>
      <td>0.445399</td>
      <td>1.301227</td>
      <td>1.739428</td>
      <td>0.753108</td>
      <td>6.833453</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1320.0</th>
      <td>0.798439</td>
      <td>0.074218</td>
      <td>2.230427</td>
      <td>0.209307</td>
      <td>0.117438</td>
      <td>1.418060</td>
      <td>0.400087</td>
      <td>0.356209</td>
      <td>0.303004</td>
      <td>1.574167</td>
      <td>0.278414</td>
      <td>4.329142</td>
      <td>0.181920</td>
      <td>2.541780</td>
      <td>1.145212</td>
      <td>0.230039</td>
      <td>2.305600</td>
      <td>0.398928</td>
    </tr>
    <tr>
      <th>1760.0</th>
      <td>1.161748</td>
      <td>0.041790</td>
      <td>0.274885</td>
      <td>0.083307</td>
      <td>0.054024</td>
      <td>0.424709</td>
      <td>0.266510</td>
      <td>NaN</td>
      <td>0.036932</td>
      <td>0.327422</td>
      <td>0.077146</td>
      <td>0.878266</td>
      <td>0.136665</td>
      <td>2.780772</td>
      <td>0.294795</td>
      <td>0.123320</td>
      <td>4.410869</td>
      <td>0.070949</td>
    </tr>
    <tr>
      <th>2200.0</th>
      <td>0.419192</td>
      <td>0.006516</td>
      <td>0.689737</td>
      <td>0.025070</td>
      <td>0.112100</td>
      <td>0.528485</td>
      <td>0.090443</td>
      <td>0.167185</td>
      <td>0.090113</td>
      <td>0.046026</td>
      <td>0.062842</td>
      <td>1.307342</td>
      <td>0.106966</td>
      <td>2.647956</td>
      <td>0.049579</td>
      <td>0.174445</td>
      <td>0.453623</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
def mse(actual, pred): 
    #actual, pred = np.array(actual), np.array(pred)
    
    MAE = True
    MSE = False
    logMSE = False
    logMAE = False
    if MSE: return np.square(np.subtract(actual,pred)).mean()
    if MAE: return np.abs(   np.subtract(actual, pred)).mean()
    if logMSE: return np.square(np.subtract(np.log(actual),np.log(pred))).mean()
    if logMAE: return np.abs(   np.subtract(np.log(actual), np.log(pred))).mean()

```


```python
#from sklearn.metrics import mean_squared_error
#predicted =y_pred.as_matrix()
#actual= y_true.as_matrix()
#mean_squared_error(actual, predicted)
```


```python
dfum = dfu.join(dfm.set_index('istm'),on='istm',rsuffix='_map')
dfum.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>train</th>
      <th>istm</th>
      <th>note</th>
      <th>freq</th>
      <th>magn</th>
      <th>class</th>
      <th>classn</th>
      <th>rfreq</th>
      <th>class_map</th>
      <th>classn_map</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>440.00</td>
      <td>1.000000</td>
      <td>0</td>
      <td>0.0</td>
      <td>440.0</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>881.98</td>
      <td>10.699971</td>
      <td>0</td>
      <td>0.0</td>
      <td>880.0</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>1321.98</td>
      <td>0.798439</td>
      <td>0</td>
      <td>0.0</td>
      <td>1320.0</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>1763.96</td>
      <td>1.161748</td>
      <td>0</td>
      <td>0.0</td>
      <td>1760.0</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>2203.96</td>
      <td>0.419192</td>
      <td>0</td>
      <td>0.0</td>
      <td>2200.0</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
def get_ct_mse(ct):

    dfe = pd.DataFrame({'test':[],'train':[],'MSE':[]})

    for LL in dfu[dfu.train==0].label.unique():
        for RR in dfu[dfu.train==1].label.unique():
            if LL!=RR:
                df = pd.DataFrame([{ 'test':LL, 'train':RR, 'MSE':mse(ct[LL], ct[RR]) }])        
                dfe = pd.concat([dfe, df],ignore_index=True)
    
    return dfe
    
```


```python
dfe = get_ct_mse(ctab_rnd)
```


```python
dfes = dfe.sort_values(by=['test','MSE'],ascending=[True,True])
dfes['rank'] = dfes.groupby('test')['MSE'].rank('dense')
dfes = dfes.query('rank==1')
```


```python
dfes
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>test</th>
      <th>train</th>
      <th>MSE</th>
      <th>rank</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>8</th>
      <td>Bassoon3a_x</td>
      <td>Flute1a</td>
      <td>0.227260</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Cello3a_x</td>
      <td>Viola1a</td>
      <td>0.405850</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>65</th>
      <td>Clarinet3a_x</td>
      <td>Cello2a</td>
      <td>0.032699</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Flute3a_x</td>
      <td>Bassoon1a</td>
      <td>0.849626</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>44</th>
      <td>FrHorn3a_x</td>
      <td>Flute1a</td>
      <td>0.094683</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Viola3a_x</td>
      <td>Clarinet2a</td>
      <td>0.021359</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2export = dfes.join(
                dfu[['label','class']].drop_duplicates().set_index('label'),
                on='train')[['test','class']].rename(columns={
                    'test':'test_sample','class':'predicted_class'
                })
df2export
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>test_sample</th>
      <th>predicted_class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>8</th>
      <td>Bassoon3a_x</td>
      <td>4</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Cello3a_x</td>
      <td>1</td>
    </tr>
    <tr>
      <th>65</th>
      <td>Clarinet3a_x</td>
      <td>2</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Flute3a_x</td>
      <td>0</td>
    </tr>
    <tr>
      <th>44</th>
      <td>FrHorn3a_x</td>
      <td>4</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Viola3a_x</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
df2export.reset_index(drop=True).to_csv('modelprediction.MAE_ON_MEAN_ROUNDED_PEAKFREQS.1.csv')
```

## preparation of X_train, y_train, X_test, y_test


```python
dfu.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>train</th>
      <th>istm</th>
      <th>note</th>
      <th>freq</th>
      <th>magn</th>
      <th>class</th>
      <th>classn</th>
      <th>rfreq</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>440.00</td>
      <td>1.000000</td>
      <td>0</td>
      <td>0.0</td>
      <td>440.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>881.98</td>
      <td>10.699971</td>
      <td>0</td>
      <td>0.0</td>
      <td>880.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>1321.98</td>
      <td>0.798439</td>
      <td>0</td>
      <td>0.0</td>
      <td>1320.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>1763.96</td>
      <td>1.161748</td>
      <td>0</td>
      <td>0.0</td>
      <td>1760.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bassoon1a</td>
      <td>1</td>
      <td>Bassoon</td>
      <td>A3</td>
      <td>2203.96</td>
      <td>0.419192</td>
      <td>0</td>
      <td>0.0</td>
      <td>2200.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
def get_features(dfu,dfm):
    dfut = dfu[['label','istm','train']].drop_duplicates().set_index('label')
    ctabf = pd.crosstab( index = dfu.label, columns = dfu.rfreq, values=dfu.magn, aggfunc='max')
    ctab_w_trainflag = ctabf.join(dfut)
    dfmi = dfm.set_index('istm')
    # join on ctab_w_trainflag.istm = dfm.istm and take dfm.class :
    ctab_w_trainflag = ctab_w_trainflag.join(dfmi,on='istm', rsuffix='_map')
    return ctab_w_trainflag
```


```python
ft = get_features(dfu,dfm).fillna(value=0)
ft
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>440.0</th>
      <th>880.0</th>
      <th>1320.0</th>
      <th>1760.0</th>
      <th>2200.0</th>
      <th>2640.0</th>
      <th>3080.0</th>
      <th>3520.0</th>
      <th>3960.0</th>
      <th>4400.0</th>
      <th>...</th>
      <th>6600.0</th>
      <th>7040.0</th>
      <th>7480.0</th>
      <th>7920.0</th>
      <th>8360.0</th>
      <th>9240.0</th>
      <th>istm</th>
      <th>train</th>
      <th>class</th>
      <th>classn</th>
    </tr>
    <tr>
      <th>label</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Bassoon1a</th>
      <td>1.0</td>
      <td>10.699971</td>
      <td>0.798439</td>
      <td>1.161748</td>
      <td>0.419192</td>
      <td>1.332462</td>
      <td>0.536774</td>
      <td>0.058731</td>
      <td>0.281313</td>
      <td>0.031251</td>
      <td>...</td>
      <td>0.028234</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.068222</td>
      <td>0.029593</td>
      <td>0.000000</td>
      <td>Bassoon</td>
      <td>1</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Bassoon2a</th>
      <td>1.0</td>
      <td>0.954465</td>
      <td>0.074218</td>
      <td>0.041790</td>
      <td>0.006516</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Bassoon</td>
      <td>1</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Bassoon3a_x</th>
      <td>1.0</td>
      <td>1.287160</td>
      <td>2.230427</td>
      <td>0.274885</td>
      <td>0.689737</td>
      <td>0.617270</td>
      <td>0.022417</td>
      <td>0.136420</td>
      <td>0.020335</td>
      <td>0.066961</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Bassoon</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>Cello1a</th>
      <td>1.0</td>
      <td>0.715145</td>
      <td>0.209307</td>
      <td>0.083307</td>
      <td>0.025070</td>
      <td>0.105560</td>
      <td>0.013563</td>
      <td>0.019858</td>
      <td>0.017487</td>
      <td>0.009499</td>
      <td>...</td>
      <td>0.007821</td>
      <td>0.007100</td>
      <td>0.004517</td>
      <td>0.008440</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Cello</td>
      <td>1</td>
      <td>2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>Cello2a</th>
      <td>1.0</td>
      <td>0.216723</td>
      <td>0.117438</td>
      <td>0.054024</td>
      <td>0.112100</td>
      <td>0.100857</td>
      <td>0.023295</td>
      <td>0.027132</td>
      <td>0.019330</td>
      <td>0.013535</td>
      <td>...</td>
      <td>0.007839</td>
      <td>0.007465</td>
      <td>0.000000</td>
      <td>0.009602</td>
      <td>0.000000</td>
      <td>0.004936</td>
      <td>Cello</td>
      <td>1</td>
      <td>2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>Cello3a_x</th>
      <td>1.0</td>
      <td>3.258891</td>
      <td>1.418060</td>
      <td>0.424709</td>
      <td>0.528485</td>
      <td>1.091763</td>
      <td>0.129301</td>
      <td>0.085218</td>
      <td>0.230562</td>
      <td>0.128349</td>
      <td>...</td>
      <td>0.115406</td>
      <td>0.100061</td>
      <td>0.072069</td>
      <td>0.000000</td>
      <td>0.039897</td>
      <td>0.032766</td>
      <td>Cello</td>
      <td>0</td>
      <td>2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>Clarinet1a</th>
      <td>1.0</td>
      <td>0.257076</td>
      <td>0.400087</td>
      <td>0.266510</td>
      <td>0.090443</td>
      <td>0.046238</td>
      <td>0.018496</td>
      <td>0.012652</td>
      <td>0.028666</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Clarinet</td>
      <td>1</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>Clarinet2a</th>
      <td>1.0</td>
      <td>0.268549</td>
      <td>0.356209</td>
      <td>0.000000</td>
      <td>0.167185</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Clarinet</td>
      <td>1</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>Clarinet3a_x</th>
      <td>1.0</td>
      <td>0.039384</td>
      <td>0.303004</td>
      <td>0.036932</td>
      <td>0.090113</td>
      <td>0.084304</td>
      <td>0.071595</td>
      <td>0.024146</td>
      <td>0.015227</td>
      <td>0.008289</td>
      <td>...</td>
      <td>0.020491</td>
      <td>0.023030</td>
      <td>0.000000</td>
      <td>0.017808</td>
      <td>0.013841</td>
      <td>0.000000</td>
      <td>Clarinet</td>
      <td>0</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>Flute1a</th>
      <td>1.0</td>
      <td>1.554169</td>
      <td>1.574167</td>
      <td>0.327422</td>
      <td>0.046026</td>
      <td>0.255016</td>
      <td>0.036796</td>
      <td>0.000000</td>
      <td>0.021095</td>
      <td>0.018532</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Flute</td>
      <td>1</td>
      <td>4</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>Flute2a</th>
      <td>1.0</td>
      <td>0.953322</td>
      <td>0.278414</td>
      <td>0.077146</td>
      <td>0.062842</td>
      <td>0.031752</td>
      <td>0.028350</td>
      <td>0.011632</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Flute</td>
      <td>1</td>
      <td>4</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>Flute3a_x</th>
      <td>1.0</td>
      <td>7.179289</td>
      <td>4.329142</td>
      <td>0.878266</td>
      <td>1.307342</td>
      <td>1.203011</td>
      <td>0.179433</td>
      <td>0.382006</td>
      <td>0.058080</td>
      <td>0.054220</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Flute</td>
      <td>0</td>
      <td>4</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>FrHorn1a</th>
      <td>1.0</td>
      <td>0.445399</td>
      <td>0.181920</td>
      <td>0.136665</td>
      <td>0.106966</td>
      <td>0.021604</td>
      <td>0.033301</td>
      <td>0.020499</td>
      <td>0.011339</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.007018</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>FrHorn</td>
      <td>1</td>
      <td>3</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>FrHorn2a</th>
      <td>1.0</td>
      <td>1.301227</td>
      <td>2.541780</td>
      <td>2.780772</td>
      <td>2.647956</td>
      <td>1.631959</td>
      <td>0.804445</td>
      <td>0.394360</td>
      <td>0.272807</td>
      <td>0.229386</td>
      <td>...</td>
      <td>0.015398</td>
      <td>0.027059</td>
      <td>0.032573</td>
      <td>0.018066</td>
      <td>0.014847</td>
      <td>0.000000</td>
      <td>FrHorn</td>
      <td>1</td>
      <td>3</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>FrHorn3a_x</th>
      <td>1.0</td>
      <td>1.739428</td>
      <td>1.145212</td>
      <td>0.294795</td>
      <td>0.049579</td>
      <td>0.070098</td>
      <td>0.039151</td>
      <td>0.070300</td>
      <td>0.035180</td>
      <td>0.018931</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>FrHorn</td>
      <td>0</td>
      <td>3</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>Viola1a</th>
      <td>1.0</td>
      <td>0.753108</td>
      <td>0.230039</td>
      <td>0.123320</td>
      <td>0.174445</td>
      <td>0.132477</td>
      <td>0.093797</td>
      <td>0.031227</td>
      <td>0.037235</td>
      <td>0.019406</td>
      <td>...</td>
      <td>0.005253</td>
      <td>0.009041</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Viola</td>
      <td>1</td>
      <td>1</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>Viola2a</th>
      <td>1.0</td>
      <td>6.833453</td>
      <td>2.305600</td>
      <td>4.410869</td>
      <td>0.453623</td>
      <td>0.359356</td>
      <td>0.846792</td>
      <td>0.099655</td>
      <td>0.000000</td>
      <td>0.077626</td>
      <td>...</td>
      <td>0.054061</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.046296</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Viola</td>
      <td>1</td>
      <td>1</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>Viola3a_x</th>
      <td>1.0</td>
      <td>0.000000</td>
      <td>0.398928</td>
      <td>0.070949</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>Viola</td>
      <td>0</td>
      <td>1</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
<p>18 rows × 24 columns</p>
</div>




```python
X_train = ft.query("train==1").drop(['istm','class','train'],axis=1)
y_train = ft.query("train==1")[['class']]
X_test = ft.query("train==0").drop(['istm','class','train'],axis=1)
y_test = ft.query("train==0")[['class']] # will be compared against the model_prediction
```


```python
print(X_train.shape, y_train.shape)
print(X_test.shape, y_test.shape)
```

    (12, 21) (12, 1)
    (6, 21) (6, 1)
    


```python
def get_enriched_prediction(X_test,model_prediction):
    keys_of_test_set = X_test.reset_index()[['label']]
    predn = pd.DataFrame(model_prediction, columns=['predicted_classn'])
    df_vs = pd.concat([keys_of_test_set,predn],ignore_index=True,axis=1)
    df_vs = df_vs.rename(columns={1:'predicted_class',0:'test_sample'})
    assert df_vs.columns.tolist() == ['test_sample','predicted_class']
    return df_vs
```

# approach 3 - sklearn


```python
import pandas as pd
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
```


```python
SVC_model = SVC()
```


```python
mo = SVC_model.fit(X_train, y_train)
```

    C:\Users\Alberto\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.8_qbz5n2kfra8p0\LocalCache\local-packages\Python38\site-packages\sklearn\utils\validation.py:1688: FutureWarning: Feature names only support names that are all strings. Got feature names with dtypes: ['float', 'str']. An error will be raised in 1.2.
      warnings.warn(
    C:\Users\Alberto\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.8_qbz5n2kfra8p0\LocalCache\local-packages\Python38\site-packages\sklearn\utils\validation.py:993: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    


```python
SVC_prediction = SVC_model.predict(X_test)
```

    C:\Users\Alberto\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.8_qbz5n2kfra8p0\LocalCache\local-packages\Python38\site-packages\sklearn\utils\validation.py:1688: FutureWarning: Feature names only support names that are all strings. Got feature names with dtypes: ['float', 'str']. An error will be raised in 1.2.
      warnings.warn(
    

## saving predictions made by SVC


```python
dfp = get_enriched_prediction(X_test,SVC_prediction)
dfp.to_csv('modelprediction.SVC.1.csv')
```

# approach 4 - deep learning


```python
# https://scikit-learn.org/stable/modules/neural_networks_supervised.html
```


```python
# https://scikit-learn.org/stable/modules/neural_networks_supervised.html

from sklearn.neural_network import MLPClassifier

#X = [[0., 0.], [1., 1.]]
#y = [[0, 1], [1, 1]]

clf = MLPClassifier(solver='lbfgs', alpha=1e-5,
                    hidden_layer_sizes=(15,), random_state=1)

clf.fit(X_train, y_train)

MLP_prediction = clf.predict(X_test)


```

    C:\Users\Alberto\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.8_qbz5n2kfra8p0\LocalCache\local-packages\Python38\site-packages\sklearn\utils\validation.py:1688: FutureWarning: Feature names only support names that are all strings. Got feature names with dtypes: ['float', 'str']. An error will be raised in 1.2.
      warnings.warn(
    C:\Users\Alberto\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.8_qbz5n2kfra8p0\LocalCache\local-packages\Python38\site-packages\sklearn\neural_network\_multilayer_perceptron.py:1109: DataConversionWarning: A column-vector y was passed when a 1d array was expected. Please change the shape of y to (n_samples, ), for example using ravel().
      y = column_or_1d(y, warn=True)
    C:\Users\Alberto\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.8_qbz5n2kfra8p0\LocalCache\local-packages\Python38\site-packages\sklearn\utils\validation.py:1688: FutureWarning: Feature names only support names that are all strings. Got feature names with dtypes: ['float', 'str']. An error will be raised in 1.2.
      warnings.warn(
    

## saving predictions made by MLPClassifier


```python
dfp = get_enriched_prediction(X_test,MLP_prediction)
dfp.to_csv('modelprediction.MLP.1.csv')
```

# comment
* ...


```python
print('thank you.')
```

    thank you.
    

# END OF model_deployment document


```python

```
